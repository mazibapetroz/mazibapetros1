#advanced concept - strings

message = ' Hello, World!'

print(message.strip())# Remove leading and trailling whitespace
print(message.lower())# convert all characters to lowercase
print(message.split(','))# split the string into a list based on comma

#upper method?
#replace method?