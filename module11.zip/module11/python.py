#Loops

#using a loop to count from 1 to 5
count = 1

while count <= 5:
    print(count)
    count += 1 # increment the count by 1