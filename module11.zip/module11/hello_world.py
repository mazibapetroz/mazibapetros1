
print("hello world")
 